(function () {
    if (!window.jabvfcr) {
        return;
    }
    jQuery(jabvfcr.selector)[jabvfcr.manipulation](jabvfcr.html);
})();